function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5mL6hTqMeVs":
        Script1();
        break;
      case "5mckLXM4ua1":
        Script2();
        break;
      case "5fmKuvJGc63":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5fMWKPqgUvS":
        Script1();
        break;
      case "62rGP2luI3k":
        Script2();
        break;
      case "678QaxTFMBd":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6g7imMdBMsB":
        Script1();
        break;
      case "5rxa10QuMfi":
        Script2();
        break;
      case "61QufCZVtRB":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Dhc0HTn89W":
        Script1();
        break;
      case "6Kl7de65PGu":
        Script2();
        break;
      case "6UnZL3wM2om":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


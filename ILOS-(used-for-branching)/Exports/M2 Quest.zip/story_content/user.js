function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6iZZgxNbRsG":
        Script1();
        break;
      case "5m8TFUZgV6e":
        Script2();
        break;
      case "5uKdcl7kKpl":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


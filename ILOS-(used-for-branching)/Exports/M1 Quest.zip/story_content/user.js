function ExecuteScript(strId)
{
  switch (strId)
  {
      case "66ppCgwC8BI":
        Script1();
        break;
      case "6AYc87sA4XP":
        Script2();
        break;
      case "6OiUMz8MhlC":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5xBTDdA4oEt":
        Script1();
        break;
      case "6itKdvag6Zf":
        Script2();
        break;
      case "5x2Aae1wVDg":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


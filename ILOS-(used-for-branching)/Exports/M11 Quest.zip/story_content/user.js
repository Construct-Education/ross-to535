function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6PLht4qu7Uz":
        Script1();
        break;
      case "5cgYhid2pYw":
        Script2();
        break;
      case "6r2ilx6N9h1":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


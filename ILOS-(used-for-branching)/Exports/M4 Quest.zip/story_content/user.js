function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Eju9XtsRNf":
        Script1();
        break;
      case "6XsyDkCG9M6":
        Script2();
        break;
      case "6Sv6E5U8wv0":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


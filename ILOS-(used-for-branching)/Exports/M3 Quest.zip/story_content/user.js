function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6mPCoe5vleF":
        Script1();
        break;
      case "6XB2SKWT5If":
        Script2();
        break;
      case "6N30yZgKTYv":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6RBJj4UVOi4":
        Script1();
        break;
      case "5ertu7lGRJG":
        Script2();
        break;
      case "5ybBE4Jeshm":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


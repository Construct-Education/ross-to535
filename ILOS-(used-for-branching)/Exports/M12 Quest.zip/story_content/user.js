function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5lSPi7ADA3g":
        Script1();
        break;
      case "6atK3NwdNcC":
        Script2();
        break;
      case "5XGCxBOuApR":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


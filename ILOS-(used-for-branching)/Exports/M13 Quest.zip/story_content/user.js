function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6A1QHhKRt9t":
        Script1();
        break;
      case "6jvh6mu1vEF":
        Script2();
        break;
      case "6FWnQr2I8mp":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}


function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5krlUothbmZ":
        Script1();
        break;
      case "6G5Kg1fyPmf":
        Script2();
        break;
      case "6JlAL096eBO":
        Script3();
        break;
  }
}

function Script1()
{
  window.top.changeButtonURL();
}

function Script2()
{
  parent.changeButtonURL();
}

function Script3()
{
  window.top.changeButtonURL();
}

